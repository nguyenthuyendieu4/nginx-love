# Cloudflare DNS Manager Plugin

A plugin for Nginx Love that allows you to manage Cloudflare DNS records directly from the admin panel.

## Features

- ✅ List all Cloudflare zones (domains)
- ✅ View DNS records for each domain
- ✅ Add new DNS records (A, AAAA, CNAME, MX, TXT, NS, SRV)
- ✅ Edit existing DNS records
- ✅ Delete DNS records
- ✅ Proxy settings (orange cloud)
- ✅ Custom TTL configuration
- ✅ MX record priority support

## Installation

### Via Nginx Love Plugin Manager

1. Go to **Plugins** → **Marketplace** in your admin panel
2. Search for "Cloudflare DNS Manager"
3. Click **Install**
4. Click **Activate**

### Manual Installation

1. Extract plugin files to `/data/plugins/cloudflare-dns-manager/`
2. Install dependencies:
   ```bash
   cd /data/plugins/cloudflare-dns-manager
   npm install
   ```
3. Activate plugin from admin panel

## Configuration

1. Go to **Cloudflare DNS** in the sidebar
2. Enter your Cloudflare credentials:
   - **Email**: Your Cloudflare account email
   - **API Key**: Your Global API Key (found in Cloudflare dashboard under Profile → API Tokens)
3. Click **Save Settings**

### Getting Cloudflare API Key

1. Log in to [Cloudflare Dashboard](https://dash.cloudflare.com/)
2. Click on your profile icon → **My Profile**
3. Go to **API Tokens** tab
4. Under **Global API Key**, click **View**
5. Copy the key and paste it in the plugin settings

## Usage

### Managing DNS Records

1. After configuration, you'll see a list of your Cloudflare domains
2. Click **Manage DNS** on any domain
3. You can now:
   - **Add Record**: Click the "+ Add Record" button
   - **Edit Record**: Click "Edit" on any record
   - **Delete Record**: Click "Delete" on any record

### Record Types Supported

- **A**: IPv4 address
- **AAAA**: IPv6 address
- **CNAME**: Canonical name (alias)
- **MX**: Mail exchange (with priority)
- **TXT**: Text record
- **NS**: Name server
- **SRV**: Service record

### Proxy Settings

- Enable "Proxy through Cloudflare" for web traffic (HTTP/HTTPS)
- This will route traffic through Cloudflare's CDN (orange cloud icon)
- Only available for A, AAAA, and CNAME records

## API Endpoints

The plugin exposes the following API endpoints:

### Zones
- `GET /api/plugins/cloudflare/zones` - List all zones
- `GET /api/plugins/cloudflare/zones/:zoneId/records` - Get DNS records

### DNS Records
- `POST /api/plugins/cloudflare/zones/:zoneId/records` - Create record
- `PUT /api/plugins/cloudflare/zones/:zoneId/records/:recordId` - Update record
- `DELETE /api/plugins/cloudflare/zones/:zoneId/records/:recordId` - Delete record

### Settings
- `GET /api/plugins/cloudflare/settings` - Get settings
- `POST /api/plugins/cloudflare/settings` - Save settings

## Permissions

The plugin requires the following permissions:

- `cloudflare:read` - View zones and records
- `cloudflare:write` - Create, update, delete records
- `cloudflare:settings` - Manage plugin settings

## Security

- API credentials are stored securely in the plugin database
- All API requests are made server-side
- Credentials are never exposed to the client
- Input validation on all operations
- Cloudflare API authentication verification

## Troubleshooting

### "Invalid Cloudflare API credentials"
- Make sure you're using the Global API Key (not API Token)
- Verify your email address is correct
- Check that your API key hasn't been rotated

### "Failed to load domains"
- Ensure your Cloudflare account has at least one domain
- Check your API credentials are configured correctly
- Verify the plugin is activated

### "Failed to save record"
- Check the record format is correct
- Ensure the domain name is valid
- Verify you have permission to manage DNS for this zone

## Support

For issues and feature requests:
- GitHub: https://github.com/nginx-love/cloudflare-dns-manager
- Email: support@nginx-love.com

## License

MIT License - see LICENSE file for details

## Version History

### 1.0.0 (2025-10-15)
- Initial release
- Basic DNS record management
- Cloudflare API integration
- Web interface for easy management
